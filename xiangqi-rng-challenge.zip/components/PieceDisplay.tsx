
import React from 'react';
import { Piece, PlayerColor } from '../types';
import { PIECE_UNICODE } from '../constants';

interface PieceDisplayProps {
  piece: Piece;
  isSelected: boolean;
}

const PieceDisplay: React.FC<PieceDisplayProps> = ({ piece, isSelected }) => {
  const pieceChar = PIECE_UNICODE[piece.color][piece.type];
  const colorClass = piece.color === PlayerColor.RED ? 'text-red-600' : 'text-black';
  const selectedClass = isSelected ? 'ring-2 ring-blue-500 rounded-full' : '';
  
  return (
    <div className={`w-full h-full flex items-center justify-center text-3xl sm:text-4xl font-bold ${colorClass} ${selectedClass} cursor-pointer`}>
      {pieceChar}
    </div>
  );
};

export default PieceDisplay;
    