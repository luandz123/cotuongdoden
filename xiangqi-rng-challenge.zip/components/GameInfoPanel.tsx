
import React from 'react';
import { PlayerColor, PieceType } from '../types';
import { PIECE_UNICODE } from '../constants';

interface GameInfoPanelProps {
  currentPlayer: PlayerColor;
  currentTurnMoves: PieceType[];
  currentMoveInTurnIndex: number;
  message: string;
  gameStatus: string;
  onResetGame: () => void;
  onSkipSubTurn?: () => void; // Optional: for manual skip if auto-skip isn't enough
  canSkip: boolean;
}

const GameInfoPanel: React.FC<GameInfoPanelProps> = ({
  currentPlayer,
  currentTurnMoves,
  currentMoveInTurnIndex,
  message,
  gameStatus,
  onResetGame,
  onSkipSubTurn,
  canSkip
}) => {
  const getPlayerColorClass = (player: PlayerColor) => {
    return player === PlayerColor.RED ? 'text-red-600' : 'text-black';
  };

  return (
    <div className="p-4 bg-neutral-100 shadow-lg rounded-lg w-full md:w-96 flex flex-col space-y-4">
      <h2 className="text-2xl font-bold text-center text-neutral-700">Xiangqi RNG Challenge</h2>
      
      <div className="text-center">
        <p className="text-lg">
          Current Player: <span className={`font-semibold ${getPlayerColorClass(currentPlayer)}`}>{currentPlayer}</span>
        </p>
      </div>

      {gameStatus === 'ongoing' || gameStatus === 'check' ? (
        <div>
          <h3 className="text-md font-semibold text-neutral-600 mb-1">Moves for this turn:</h3>
          <div className="flex justify-around items-center bg-neutral-200 p-2 rounded">
            {currentTurnMoves.map((pieceType, index) => (
              <div 
                key={index} 
                className={`text-3xl p-1 rounded ${index === currentMoveInTurnIndex ? 'ring-2 ring-blue-500 bg-blue-100 scale-110' : 'opacity-50'}`}
                title={pieceType}
              >
                {PIECE_UNICODE[currentPlayer][pieceType] || '?'}
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="p-3 bg-yellow-100 border border-yellow-300 rounded min-h-[60px] text-center flex items-center justify-center">
        <p className={`text-sm font-medium ${message.includes("wins") || message.includes("Checkmate") ? 'text-green-700' : message.includes("Check!") ? 'text-red-700 animate-pulse' : 'text-neutral-700'}`}>
          {message || " "}
        </p>
      </div>
      
      {onSkipSubTurn && gameStatus !== 'red_wins' && gameStatus !== 'black_wins' && gameStatus !== 'draw_stalemate' && (
         <button
          onClick={onSkipSubTurn}
          disabled={!canSkip}
          className={`w-full px-4 py-2 rounded font-semibold transition-colors
                      ${canSkip 
                        ? 'bg-orange-500 hover:bg-orange-600 text-white' 
                        : 'bg-neutral-300 text-neutral-500 cursor-not-allowed'}`}
        >
          Skip Current Piece Move (if stuck)
        </button>
      )}


      <button
        onClick={onResetGame}
        className="w-full px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded font-semibold transition-colors"
      >
        Reset Game
      </button>
    </div>
  );
};

export default GameInfoPanel;
    