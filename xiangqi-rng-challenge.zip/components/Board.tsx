
import React from 'react';
import { BoardState, Coordinates, Piece, PlayerColor, PieceType } from '../types';
import PieceDisplay from './PieceDisplay';
import { BOARD_ROWS, BOARD_COLS } from '../constants';

interface BoardProps {
  boardState: BoardState;
  selectedPieceInfo: { piece: Piece; coords: Coordinates } | null;
  validMoves: Coordinates[];
  onSquareClick: (row: number, col: number) => void;
  currentPlayer: PlayerColor;
  currentActivePieceType: PieceType | null; // The piece type player must move
}

const Board: React.FC<BoardProps> = ({
  boardState,
  selectedPieceInfo,
  validMoves,
  onSquareClick,
  currentPlayer,
  currentActivePieceType,
}) => {
  // Create an array for rows in reverse for typical Xiangqi display (Red at bottom)
  const displayRows = Array.from({ length: BOARD_ROWS }, (_, i) => BOARD_ROWS - 1 - i);

  const getSquareClasses = (row: number, col: number, piece: Piece | null): string => {
    let base = 'w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 border border-neutral-400 flex items-center justify-center relative';
    
    // Background for squares
    base += (row + col) % 2 === 0 ? ' bg-amber-200' : ' bg-amber-100';

    const isSelected = selectedPieceInfo?.coords.row === row && selectedPieceInfo?.coords.col === col;
    if (isSelected) {
      base += ' ring-2 ring-offset-1 ring-blue-600';
    }

    const isValidMove = validMoves.some(move => move.row === row && move.col === col);
    if (isValidMove) {
      base += ' bg-green-300 opacity-80';
      if (piece) base += ' border-2 border-green-700'; // Highlight capture
    }
    
    if (piece && piece.color === currentPlayer && piece.type === currentActivePieceType && !isSelected) {
      base += ' shadow-lg shadow-sky-400/50'; // Hint for selectable pieces
    }

    return base;
  };

  // Draw lines for Xiangqi board
  const renderGridLines = () => {
    const lines = [];
    // Horizontal lines (rendered relative to squares)
    for (let r = 0; r < BOARD_ROWS -1; r++) {
        for (let c = 0; c < BOARD_COLS; c++) {
             lines.push(<div key={`h-${r}-${c}`} className="absolute bg-neutral-600" style={{ top: `${(r + 1) * (100/BOARD_ROWS)}%`, left: `${c * (100/BOARD_COLS)}%`, width: `${100/BOARD_COLS}%`, height: '1px', transform: 'translateY(-0.5px)' }}></div>);
        }
    }
    // Vertical lines
    for (let c = 0; c < BOARD_COLS -1; c++) {
        for (let r = 0; r < BOARD_ROWS; r++) {
            lines.push(<div key={`v-${r}-${c}`} className="absolute bg-neutral-600" style={{ left: `${(c + 1) * (100/BOARD_COLS)}%`, top: `${r * (100/BOARD_ROWS)}%`, height: `${100/BOARD_ROWS}%`, width: '1px', transform: 'translateX(-0.5px)' }}></div>);
        }
    }

    // Palace lines (Diagonals) - Simplified
    // Red Palace (bottom)
    lines.push(<div key="palace-r1" className="absolute bg-neutral-600" style={{ top: `${0}%`, left: `${3 * (100/BOARD_COLS)}%`, width: `${2 * (100/BOARD_COLS)}%`, height: '1px', transform: `rotate(45deg) scaleX(1.414) translateX(-${0.5 * (100/BOARD_COLS)}%) translateY(${0.5 * (100/BOARD_ROWS)}%)`, transformOrigin: 'top left' }}></div>);
    lines.push(<div key="palace-r2" className="absolute bg-neutral-600" style={{ top: `${0}%`, left: `${5 * (100/BOARD_COLS)}%`, width: `${2 * (100/BOARD_COLS)}%`, height: '1px', transform: `rotate(-45deg) scaleX(1.414) translateX(${0.5 * (100/BOARD_COLS)}%) translateY(${0.5 * (100/BOARD_ROWS)}%)`, transformOrigin: 'top right' }}></div>);

    // Black Palace (top, visually) - remember rows are inverted for display
     lines.push(<div key="palace-b1" className="absolute bg-neutral-600" style={{ bottom: `${0}%`, left: `${3 * (100/BOARD_COLS)}%`, width: `${2 * (100/BOARD_COLS)}%`, height: '1px', transform: `rotate(-45deg) scaleX(1.414) translateX(-${0.5 * (100/BOARD_COLS)}%) translateY(-${0.5 * (100/BOARD_ROWS)}%)`, transformOrigin: 'bottom left' }}></div>);
    lines.push(<div key="palace-b2" className="absolute bg-neutral-600" style={{ bottom: `${0}%`, left: `${5 * (100/BOARD_COLS)}%`, width: `${2 * (100/BOARD_COLS)}%`, height: '1px', transform: `rotate(45deg) scaleX(1.414) translateX(${0.5 * (100/BOARD_COLS)}%) translateY(-${0.5 * (100/BOARD_ROWS)}%)`, transformOrigin: 'bottom right' }}></div>);
    
    // River (text placeholder)
    lines.push(
      <div key="river" className="absolute text-neutral-500 text-lg sm:text-xl font-serif select-none"
           style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: '80%', textAlign: 'center' }}>
        <span className="px-2 bg-amber-100 opacity-70">楚 河</span>
        <span className="px-2 bg-amber-100 opacity-70">漢 界</span>
      </div>
    );
    return lines;
  };


  return (
    <div className="grid grid-cols-9 relative bg-amber-50 border-4 border-amber-700 shadow-2xl" style={{ aspectRatio: `${BOARD_COLS}/${BOARD_ROWS}` }}>
      {renderGridLines()}
      {displayRows.map(row => // Iterate through displayRows for correct visual order
        boardState[row].map((piece, col) => (
          <div
            key={`${row}-${col}`}
            className={getSquareClasses(row, col, piece)}
            onClick={() => onSquareClick(row, col)}
          >
            {piece && <PieceDisplay piece={piece} isSelected={selectedPieceInfo?.coords.row === row && selectedPieceInfo?.coords.col === col} />}
          </div>
        ))
      )}
    </div>
  );
};

export default Board;
    